import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Dale Benedict Ocumen");
  const bodyText = 'I am a Programmer';

  const onPressTitle = () => {
    setTitleText("Dale The Programmer");
  };


  return(
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
                <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
      <Text style={styles.normalText}>
      I am a programmer in sysarch and I did.
        <Text style={styles.baseText}>
              <Text style={styles.baseText}>
                everything that I did is for my family because I love my family. and the channel said that family is love. it is said in the song that kay ganda ng pag-ibig ang kailangan ng daigdig,
                <Text style={styles.innerText}>
                  ganda ng pag-ibig ang kailangan ng daigdig,  
                </Text>
                 kay ganda ng lahat, I we were just love.
              </Text>
            </Text>
          <Text numberOfLines={5}>{bodyText}</Text>
        </Text>
      </Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    textAlign: 'center',
  },
  baseText: {
    fontFamily: 'Cochin',
    alignItems: 'center',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  titleText: {
    fontSize: 20,
    alignItems: 'center',
    textAlign: 'center',
  },
  innerText: {
    color: 'red',
    fontWeight: 'normal',
  },
});

export default TextInANest;