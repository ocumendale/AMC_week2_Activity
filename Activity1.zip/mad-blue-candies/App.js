import React from 'react';
import {View, Text, Image, ScrollView, TextInput} from 'react-native';

const App = () => {
  return (
    <ScrollView>
      <View
        style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
      <Text>Dale Benedict Ocumen</Text>
      <Text>AMC in React Native</Text>
      <Image
        source={{
          uri: "https://dthezntil550i.cloudfront.net/ec/latest/ec2305160145567360024742816/1280_960/33c8e334-53bd-4beb-8ef4-8873b4468ce2.png"
        }}
        style={{width: 200, height: 200}}
      />
      
      <TextInput
        style={{
          height: 40,
          borderColor: 'gray',
          borderWidth: 1,
          textAlign: 'center',
        }}
        defaultValue="You can type in me"
      />
      </View>
      </ScrollView>
  );
};

export default App;