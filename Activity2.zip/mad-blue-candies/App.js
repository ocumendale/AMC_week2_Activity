import React, {useState} from 'react';
import {Text, StyleSheet} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const TextInANest = () => {
  const [titleText, setTitleText] = useState("Dale Benedict Ocumen");
  const bodyText = 'I am a Programmer in Sysarch because I am the best. everything that I did is for my family because I love my family. and the channel said that family is love. it is said in the song that kay ganda ng pag-ibig ang kailangan ng daigdig ';

  const onPressTitle = () => {
    setTitleText("Dale The Programmer");
  };


  return(
    <SafeAreaProvider>
      <SafeAreaView style={styles.container}>
        <Text style={styles.baseText}>
          <Text style={styles.titleText} onPress={onPressTitle}>
            {titleText}
            {'\n'}
            {'\n'}
            </Text>
          <Text numberOfLines={5}>{bodyText}</Text>
        </Text>
      </SafeAreaView>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    textAlign: 'center',
  },
  baseText: {
    fontFamily: 'Cochin',
    alignItems: 'center',
    textAlign: 'center',
  },
  titleText: {
    fontSize: 20,
    fontWeight: 'bold',
    alignItems: 'center',
    textAlign: 'center',
  },
  bodyText: {
    alignItems: 'center',
    textAlign: 'center',
  }
});

export default TextInANest;